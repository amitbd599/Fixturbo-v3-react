

if(window.location.pathname === "home-1-rtl"){
    
}